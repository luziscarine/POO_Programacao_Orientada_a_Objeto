#ifndef FRASEALEATORIA_H_INCLUDED
#define FRASEALEATORIA_H_INCLUDED
#include <iostream>
#include <cstring>
#include <stdlib.h>
using namespace std;

class FraseAleatoria {
private:
    string artigo [5], substantivo[5], verbo[5], preposicao[5];
public:
    FraseAleatoria();
    ~FraseAleatoria();

};

#endif // FRASEALEATORIA_H_INCLUDED
