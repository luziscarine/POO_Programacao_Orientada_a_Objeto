#include "FraseAleatoria.h"

FraseAleatoria :: FraseAleatoria()
{

}
FraseAleatoria :: ~FraseAleatoria()
{

}
